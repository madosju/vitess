The pages below this navigation entry "Design Docs" represent the design considerations
that went behind some of the features implemented. They may not be necessarily up-to-date.

Also, some of the ideas here may just be experimental proposals, and it's possible
that such ideas might have been abandonned or not implemented yet.
